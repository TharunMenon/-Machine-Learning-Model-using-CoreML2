import Cocoa
import CreateML
import Foundation


let ImagesDirectoryPath = URL(fileURLWithPath: "Users/rohan/Desktop/ImageTraining")


//Let's train the model with images
let modelBuilder = try MLImageClassifier(trainingData: .labeledDirectories(at: ImagesDirectoryPath))

// Get the path of images directory
let ImagesDirectoryPathTest = URL(fileURLWithPath: "Users/rohan/Desktop/ImageTest")

// Let's evaluate the trained model :)
let evaluation = modelBuilder.evaluation(on: .labeledDirectories(at: ImagesDirectoryPathTest))

//Save the model at spcific path
try modelBuilder.write(to: URL(fileURLWithPath: "Users/rohan/Desktop/HomeAppliancesModel.mlmodel"))
