import Cocoa
import CreateMLUI

let Modelbuilder = MLImageClassifierBuilder()
Modelbuilder.showInLiveView()
